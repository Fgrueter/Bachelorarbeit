import torch
import numpy as np
from collections import deque, namedtuple
import random
from typing import Tuple


Experience = namedtuple('Experience', ['state', 'action1', 'action2', 'action3', 'action4', 'reward', 'next_state', 'done'])
device = 'cpu'


class ExperienceReplayBuffer():
    def __init__(self, buffer_size: int, batch_size: int):
        self.memory = deque(maxlen=buffer_size)
        self.batch_size = batch_size

    def add_experience(self, state, action1,action2,action3,action4, reward, next_state, done) -> None:
        experience = Experience(state, action1,action2,action3,action4, reward,  next_state, done)
        self.memory.append(experience)

    def sample(self) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        # Grab a random batch of samples
        samples = random.sample(self.memory, k=self.batch_size)
        
        # Grab S, A, R, S_, Done from the samples and store them into a vstack
        # where each row is just a 
        states = np.vstack([sample.state for sample in samples])
        action1s = np.vstack([sample.action1 for sample in samples])
        action2s = np.vstack([sample.action2 for sample in samples])
        action3s = np.vstack([sample.action3 for sample in samples])
        action4s = np.vstack([sample.action4 for sample in samples])
        rewards = np.vstack([sample.reward for sample in samples])
        next_states = np.vstack([sample.next_state for sample in samples])
        dones = np.vstack([sample.done for sample in samples])

        # Convert the above to tensors
        states = torch.from_numpy(states).float().to(device)
        action1s = torch.from_numpy( action1s).long().to(device)
        action2s = torch.from_numpy( action2s).long().to(device)
        action3s = torch.from_numpy( action3s).long().to(device)
        action4s = torch.from_numpy( action4s).long().to(device)

        rewards = torch.from_numpy(rewards).float().to(device)
        next_states = torch.from_numpy(next_states).float().to(device)
        dones = torch.from_numpy(dones).byte().to(device)

        return states, action1s,action2s,action3s,action4s, rewards, next_states, dones

    def __len__(self) -> int:
        return len(self.memory)